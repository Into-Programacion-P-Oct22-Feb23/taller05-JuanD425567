/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema4;

import java.util.Scanner;
import java.util.Locale;

public class Problema4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        entrada.useLocale(Locale.US);

        //Variables
        int dias;
        double descuento;
        double precio;
        double subtotal;
        double total;
        double descuento2;

        System.out.println("Ingrese la cantidad de dias de hospedaje");
        dias = entrada.nextInt();
        System.out.println("Ingrese el precio diario de la habitacion");
        precio = entrada.nextDouble();

        subtotal = dias * precio;
        System.out.println("Su subtotal es");
        System.out.println(subtotal);
        
        if (dias > 5) {
            descuento = subtotal * 0.10;
            total = subtotal - descuento;
            System.out.println("Su descuento es del 10%");
            System.out.println("Su total a pagar es de");

        }
        if (dias > 10) {
            descuento = subtotal * 0.15;
            total = subtotal - descuento;
            System.out.println("Su descuento es de 15%");
            System.out.println("Su total a pagar es de");

        }
        if (dias > 15) {
            descuento = subtotal * 0.20;
            total = subtotal - descuento;
            System.out.println("Su descuento es de 20%");
            System.out.println("Su total a pagar es de");

        }

        System.out.println("Su total a pagar es");
        
    }
