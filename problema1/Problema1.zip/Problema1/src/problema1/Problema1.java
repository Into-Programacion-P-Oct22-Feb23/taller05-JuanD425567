/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema1;

import java.util.Scanner;
import java.util.Locale;

public class Problema1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner entrada = new Scanner(System.in);
        entrada.useLocale(Locale.US);
        
       //Variables
       
       double costo;
       double consumo;
       int edad;
       int descuento;
       double total;
       //Proceso
       System.out.println("Ingrese su edad");
       edad = entrada.nextInt();
       System.out.println("Ingrese el costo Kv/h");
       costo = entrada.nextDouble();
       System.out.println("Ingrese el consumo mensual de Kv");
       consumo = entrada.nextDouble();
       
       total=consumo*costo;
       
       if(edad > 65) {
          descuento = (int) (total * 0.10);
          total = total - descuento;
       }
       System.out.println("Su total a pagar es");
       System.out.println(total);
    }
    
}
