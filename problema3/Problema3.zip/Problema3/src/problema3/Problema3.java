/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema3;

import java.util.Scanner;
import java.util.Locale;

public class Problema3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        entrada.useLocale(Locale.US);
        
        //Variables
        double impuesto;
        String marca;
        String origen;
        double costo;
        int total;
        
        //Proceso
        System.out.println("Ingrese la marca del vehiculo");
        marca = entrada.nextLine();
        System.out.println("Ingrese el origen de su vehiculo");
        origen = entrada.nextLine();
        System.out.println("Ingrese el costo del vehiculo");
        costo = entrada.nextDouble();
        System.out.println("Ingrese el valor del impuesto");
        impuesto = entrada.nextDouble();
        
        total = (int) (impuesto+costo);
        
       
        
        
        
    }
    
}
